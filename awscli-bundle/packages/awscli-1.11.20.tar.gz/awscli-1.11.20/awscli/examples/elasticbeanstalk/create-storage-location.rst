**To create a storage location**

The following command creates a storage location in Amazon S3::

  aws elasticbeanstalk create-storage-location

Output::

  {
      "S3Bucket": "elasticbeanstalk-us-west-2-0123456789012"
  }
