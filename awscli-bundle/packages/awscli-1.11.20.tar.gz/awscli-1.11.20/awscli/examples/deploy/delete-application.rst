**To delete an application**

This example deletes an application that is associated with the user's AWS account.

Command::

  aws deploy delete-application --application-name WordPress_App

Output::

  None.