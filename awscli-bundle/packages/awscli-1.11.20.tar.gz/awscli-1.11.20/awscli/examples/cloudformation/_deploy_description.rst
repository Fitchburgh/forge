Deploys the specified AWS CloudFormation template by creating and then executing
a change set. The command terminates after AWS CloudFormation executes the
change set. If you want to view the change set before AWS CloudFormation
executes it, use the ``--no-execute-changeset`` flag.

To update a stack, specify the name of an existing stack. To create a new stack,
specify a new stack name.

