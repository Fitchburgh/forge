**To get the details of all Usage Plans in a region**

Command::

  aws apigateway get-usage-plans --region us-west-2

